import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import api from '../api/axios';
import { toast } from 'react-toastify';
import { Save, ArrowLeft } from 'lucide-react';

const ResumeEditor = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const isNew = id === 'new';

  const [formData, setFormData] = useState({
    title: '',
    fullName: '',
    email: '',
    phone: '',
    summary: '',
    experience: ''
  });
  const [loading, setLoading] = useState(!isNew);

  useEffect(() => {
    if (!isNew) {
      fetchResume();
    }
  }, [id]);

  const fetchResume = async () => {
    try {
      const response = await api.get(`/resumes/${id}`);
      const data = response.data.data || response.data;
      setFormData({
        title: data.title || '',
        fullName: data.fullName || '',
        email: data.email || '',
        phone: data.phone || '',
        summary: data.summary || '',
        experience: data.experience || ''
      });
    } catch (error) {
      toast.error('Failed to load resume details. Showing empty form.');
    } finally {
      setLoading(false);
    }
  };

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      // Backend ResumeDto.CreateRequest expects: title, summary, skills, experience, education
      // Map frontend fields: fullName+email+phone go into summary, experience stays as text
      const contactInfo = `Name: ${formData.fullName}\nEmail: ${formData.email}\nPhone: ${formData.phone || ''}`;
      const payload = {
        title: formData.title,
        summary: `Name: ${formData.fullName}\nEmail: ${formData.email}\nPhone: ${formData.phone || ''}\n\n${formData.summary}`,
        skills: null,
        experience: null,
        education: null
      };
      if (isNew) {
        await api.post('/resumes', payload);
        toast.success('Resume created successfully!');
      } else {
        await api.put(`/resumes/${id}`, payload);
        toast.success('Resume updated successfully!');
      }
      navigate('/resumes');
    } catch (error) {
      toast.error('Failed to save resume. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  if (loading && !isNew) return <div className="container mt-4">Loading editor...</div>;

  return (
    <div className="container" style={{ padding: '2rem 0', maxWidth: '800px' }}>
      <button onClick={() => navigate('/resumes')} className="btn btn-outline flex items-center gap-2 mb-4" style={{ border: 'none', padding: '0.5rem 0' }}>
        <ArrowLeft size={18} />
        Back to Resumes
      </button>

      <div className="card">
        <h1 style={{ fontSize: '1.5rem', fontWeight: 'bold', marginBottom: '1.5rem' }}>
          {isNew ? 'Create New Resume' : 'Edit Resume'}
        </h1>

        <form onSubmit={handleSubmit}>
          <div className="form-group">
            <label className="form-label">Resume Title (e.g., Software Engineer)</label>
            <input type="text" name="title" value={formData.title} onChange={handleChange} className="form-input" required />
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem' }}>
            <div className="form-group">
              <label className="form-label">Full Name</label>
              <input type="text" name="fullName" value={formData.fullName} onChange={handleChange} className="form-input" required />
            </div>
            <div className="form-group">
              <label className="form-label">Email</label>
              <input type="email" name="email" value={formData.email} onChange={handleChange} className="form-input" required />
            </div>
          </div>

          <div className="form-group">
            <label className="form-label">Phone</label>
            <input type="text" name="phone" value={formData.phone} onChange={handleChange} className="form-input" />
          </div>

          <div className="form-group">
            <label className="form-label">Professional Summary</label>
            <textarea name="summary" value={formData.summary} onChange={handleChange} className="form-input" rows="4"></textarea>
          </div>

          <div className="form-group mb-6">
            <label className="form-label">Work Experience</label>
            <textarea name="experience" value={formData.experience} onChange={handleChange} className="form-input" rows="6" placeholder="List your experience here..."></textarea>
          </div>

          <button type="submit" className="btn btn-primary flex items-center gap-2" disabled={loading}>
            <Save size={18} />
            {loading ? 'Saving...' : 'Save Resume'}
          </button>
        </form>
      </div>
    </div>
  );
};

export default ResumeEditor;