import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { toast } from 'react-toastify';
import { FileText } from 'lucide-react';

const LoginPage = () => {
  const [formData, setFormData] = useState({ email: '', password: '', otp: '' });
  const [loading, setLoading] = useState(false);
  const [showOtp, setShowOtp] = useState(false);
  const { login, verifyOtp } = useAuth();
  const navigate = useNavigate();

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const redirectByRole = () => {
    const token = localStorage.getItem('token');
    try {
      const payload = JSON.parse(atob(token.split('.')[1]));
      if (payload.role === 'ROLE_ADMIN') {
        navigate('/admin/dashboard');
      } else {
        navigate('/');
      }
    } catch {
      navigate('/');
    }
  };

  const handleSubmit = async (e) => {
    if (e && e.preventDefault) e.preventDefault();
    setLoading(true);
    try {
      if (showOtp) {
        await verifyOtp({ email: formData.email, otp: formData.otp, password: formData.password });
        toast.success('Login successful!');
        redirectByRole();
      } else {
        const response = await login({ email: formData.email, password: formData.password });
        if (response && response.requiresOtp) {
          setShowOtp(true);
          toast.info('OTP sent to your email. Please enter it below.');
        } else {
          toast.success('Login successful!');
          redirectByRole();
        }
      }
    } catch (error) {
      toast.error(error.response?.data?.message || 'Login failed. Please check your credentials/OTP.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="auth-container">
      <div className="card auth-card">
        <div className="text-center mb-6">
          <div style={{ display: 'flex', justifyContent: 'center', marginBottom: '1rem', color: 'var(--primary-color)' }}>
            <FileText size={48} />
          </div>
          <h1 style={{ fontSize: '1.5rem', fontWeight: 'bold' }}>Welcome Back</h1>
          <p style={{ color: 'var(--text-muted)', fontSize: '0.875rem' }}>Log in to your account</p>
        </div>
        <form onSubmit={handleSubmit} noValidate>
          {!showOtp ? (
            <>
              <div className="form-group">
                <label className="form-label">Email</label>
                <input type="email" name="email" value={formData.email} onChange={handleChange} className="form-input" required />
              </div>
              <div className="form-group mb-6">
                <label className="form-label">Password</label>
                <input type="password" name="password" value={formData.password} onChange={handleChange} className="form-input" required />
              </div>
            </>
          ) : (
            <div className="form-group mb-6">
              <label className="form-label">Enter OTP</label>
              <input type="text" name="otp" value={formData.otp} onChange={handleChange} className="form-input" placeholder="6-digit OTP" maxLength="6" required />
            </div>
          )}
          <button type="submit" onClick={handleSubmit} className="btn btn-primary" style={{ width: '100%' }} disabled={loading}>
            {loading ? 'Processing...' : showOtp ? 'Verify OTP' : 'Log In'}
          </button>
        </form>
        <p className="text-center mt-4" style={{ fontSize: '0.875rem', color: 'var(--text-muted)' }}>
          Don't have an account? <Link to="/register">Register here</Link>
        </p>
      </div>
    </div>
  );
};

export default LoginPage;