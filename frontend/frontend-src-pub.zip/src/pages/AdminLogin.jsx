import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { toast } from 'react-toastify';
import { ShieldCheck } from 'lucide-react';

const AdminLogin = () => {
  const [formData, setFormData] = useState({ email: '', password: '', otp: '' });
  const [loading, setLoading] = useState(false);
  const [showOtp, setShowOtp] = useState(false);
  const { login, verifyOtp } = useAuth();
  const navigate = useNavigate();

  const handleChange = (e) => setFormData({ ...formData, [e.target.name]: e.target.value });

  const handleSubmit = async (e) => {
    if (e && e.preventDefault) e.preventDefault();
    setLoading(true);
    try {
      if (showOtp) {
        await verifyOtp({ email: formData.email, otp: formData.otp, password: formData.password });
        // verifyOtp sets user in context; check role via decoded token
        const token = localStorage.getItem('token');
        const payload = JSON.parse(atob(token.split('.')[1]));
        if (payload.role === 'ROLE_ADMIN') {
          toast.success('Welcome, Admin!');
          navigate('/admin/dashboard');
        } else {
          toast.error('Access denied: not an admin account.');
          localStorage.removeItem('token');
          navigate('/login');
        }
      } else {
        const response = await login({ email: formData.email, password: formData.password });
        if (response && response.requiresOtp) {
          setShowOtp(true);
          toast.info('OTP sent to your email.');
        } else {
          // Direct login path
          const token = localStorage.getItem('token');
          const payload = JSON.parse(atob(token.split('.')[1]));
          if (payload.role === 'ROLE_ADMIN') {
            toast.success('Welcome, Admin!');
            navigate('/admin/dashboard');
          } else {
            toast.error('Access denied: not an admin account.');
            localStorage.removeItem('token');
            navigate('/login');
          }
        }
      }
    } catch (error) {
      toast.error(error.response?.data?.message || 'Login failed.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="auth-container">
      <div className="card auth-card">
        <div className="text-center mb-6">
          <div style={{ display: 'flex', justifyContent: 'center', marginBottom: '1rem', color: '#dc2626' }}>
            <ShieldCheck size={48} />
          </div>
          <h1 style={{ fontSize: '1.5rem', fontWeight: 'bold' }}>Admin Login</h1>
          <p style={{ color: 'var(--text-muted)', fontSize: '0.875rem' }}>Restricted access</p>
        </div>

        <form onSubmit={handleSubmit} noValidate>
          {!showOtp ? (
            <>
              <div className="form-group">
                <label className="form-label">Email</label>
                <input type="email" name="email" value={formData.email} onChange={handleChange} className="form-input" required />
              </div>
              <div className="form-group mb-6">
                <label className="form-label">Password</label>
                <input type="password" name="password" value={formData.password} onChange={handleChange} className="form-input" required />
              </div>
            </>
          ) : (
            <div className="form-group mb-6">
              <label className="form-label">Enter OTP</label>
              <input type="text" name="otp" value={formData.otp} onChange={handleChange} className="form-input" placeholder="6-digit OTP" maxLength="6" required />
            </div>
          )}
          <button type="submit" className="btn btn-primary" style={{ width: '100%', background: '#dc2626', borderColor: '#dc2626' }} disabled={loading}>
            {loading ? 'Processing...' : showOtp ? 'Verify OTP' : 'Admin Sign In'}
          </button>
        </form>
      </div>
    </div>
  );
};

export default AdminLogin;