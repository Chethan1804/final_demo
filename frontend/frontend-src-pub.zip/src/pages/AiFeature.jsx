import React, { useState } from 'react';
import api from '../api/axios';
import { toast } from 'react-toastify';
import { Wand2, Upload, AlertCircle } from 'lucide-react';

const AiFeature = () => {
  const [file, setFile] = useState(null);
  const [loading, setLoading] = useState(false);
  const [insights, setInsights] = useState(null);

  const handleFileChange = (e) => {
    setFile(e.target.files[0]);
  };

  const handleProcess = async (e) => {
    e.preventDefault();
    if (!file) {
      toast.warning('Please select a PDF file to upload.');
      return;
    }

    const formData = new FormData();
    formData.append('file', file);

    setLoading(true);
    setInsights(null);

    try {
      // Assuming the backend endpoint is /api/ai/upload or similar
      const response = await api.post('/ai/extract', formData, {
  headers: { 'Content-Type': 'multipart/form-data' }
});
      setInsights(response.data);
      toast.success('AI processing complete!');
    } catch (error) {
      toast.error('Failed to process the document. Showing mock insights.');
      // Mock insights for demo purposes
      setTimeout(() => {
        setInsights({
          score: 85,
          strengths: ['Strong technical vocabulary', 'Clear progression of roles'],
          weaknesses: ['Lacking quantifiable achievements', 'Formatting is inconsistent'],
          suggestions: 'Consider adding more metric-driven bullet points under your recent experience. Ensure your skills section includes modern frameworks like React and Spring Boot.'
        });
      }, 1000);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="container" style={{ padding: '2rem 0' }}>
      <div className="flex items-center gap-3 mb-6">
        <div style={{ backgroundColor: 'rgba(37, 99, 235, 0.1)', padding: '0.75rem', borderRadius: '0.5rem', color: 'var(--primary-color)' }}>
          <Wand2 size={32} />
        </div>
        <div>
          <h1 style={{ fontSize: '2rem', fontWeight: 'bold' }}>AI Resume Insights</h1>
          <p style={{ color: 'var(--text-muted)' }}>Upload your resume to get instant, AI-driven feedback.</p>
        </div>
      </div>

      <div className="card mb-6" style={{ maxWidth: '600px' }}>
        <form onSubmit={handleProcess}>
          <div className="form-group">
            <label className="form-label flex items-center gap-2">
              <Upload size={18} /> Upload PDF Resume
            </label>
            <input 
              type="file" 
              accept=".pdf" 
              onChange={handleFileChange} 
              className="form-input" 
              style={{ padding: '1rem' }} 
            />
          </div>
          <button type="submit" className="btn btn-primary w-full mt-4" disabled={loading || !file}>
            {loading ? 'Processing Document...' : 'Generate Insights'}
          </button>
        </form>
      </div>

      {insights && (
        <div className="card" style={{ borderLeft: '4px solid var(--primary-color)' }}>
          <h2 style={{ fontSize: '1.5rem', fontWeight: 'bold', marginBottom: '1rem' }}>Your Resume Analysis</h2>
          
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(250px, 1fr))', gap: '1.5rem', marginBottom: '1.5rem' }}>
            <div style={{ padding: '1rem', backgroundColor: 'var(--bg-color)', borderRadius: '0.5rem' }}>
              <h3 style={{ fontWeight: 'bold', color: 'var(--success-color)', marginBottom: '0.5rem' }}>Strengths</h3>
              <ul style={{ paddingLeft: '1.5rem', color: 'var(--text-main)' }}>
                {insights.strengths?.map((s, idx) => <li key={idx} style={{ marginBottom: '0.25rem' }}>{s}</li>)}
              </ul>
            </div>
            <div style={{ padding: '1rem', backgroundColor: 'var(--bg-color)', borderRadius: '0.5rem' }}>
              <h3 style={{ fontWeight: 'bold', color: 'var(--error-color)', marginBottom: '0.5rem' }}>Areas to Improve</h3>
              <ul style={{ paddingLeft: '1.5rem', color: 'var(--text-main)' }}>
                {insights.weaknesses?.map((w, idx) => <li key={idx} style={{ marginBottom: '0.25rem' }}>{w}</li>)}
              </ul>
            </div>
          </div>

          <div style={{ padding: '1rem', backgroundColor: 'rgba(37, 99, 235, 0.05)', borderRadius: '0.5rem', display: 'flex', gap: '1rem' }}>
            <AlertCircle color="var(--primary-color)" style={{ flexShrink: 0 }} />
            <div>
              <h3 style={{ fontWeight: 'bold', color: 'var(--primary-color)', marginBottom: '0.25rem' }}>AI Suggestion</h3>
              <p style={{ color: 'var(--text-main)', lineHeight: '1.6' }}>{insights.suggestions}</p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default AiFeature;